#include "StdAfx.h"
#include "Sales.h"


Sales::Sales(void)
{
}


Sales::~Sales(void)
{
}
