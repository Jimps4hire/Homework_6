#include "StdAfx.h"
#include "UI_RobotPart.h"


UI_RobotPart::UI_RobotPart(void)
{
}


UI_RobotPart::~UI_RobotPart(void)
{
}
