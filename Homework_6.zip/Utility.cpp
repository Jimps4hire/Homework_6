#include "StdAfx.h"
#include "Utility.h"
using namespace std;
using namespace System;

Utility::Utility(void)
{
}
/*
string Utility::StringToStdString(String^ str)
{
	return msclr::interop::marshal_as<std::string>(str);
}
*/
