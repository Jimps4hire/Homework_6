#include "StdAfx.h"
#include "UI_Menu.h"
#include <FL/Fl_Window.H>

Fl_Menu_Item menuitems[] = {
	{ "&File",              0, 0, 0, FL_SUBMENU },
	{ "&New File",        0, (Fl_Callback *)UI_Menu::new_cb },
	{ "&Open File...",    FL_COMMAND + 'o', (Fl_Callback *)UI_Menu::open_cb },
	{ "&Save File",       FL_COMMAND + 's', (Fl_Callback *)UI_Menu::save_cb },
	{ "Save File &As...", FL_COMMAND + FL_SHIFT + 's', (Fl_Callback *)UI_Menu::saveas_cb, 0, FL_MENU_DIVIDER },
	{ "E&xit",            FL_COMMAND + 'q', (Fl_Callback *)UI_Menu::quit_cb, 0 },
    { 0 },
	{ "&Create", 0, 0, 0, FL_SUBMENU },
	{ "Order",             FL_COMMAND + 'x', (Fl_Callback *)UI_Menu::order_cb, 0, FL_MENU_DIVIDER },
	{ "&Customer",            FL_COMMAND + 'c', (Fl_Callback *)UI_Menu::customer_cb },
	{ "Sales &Associate",           FL_COMMAND + 'a', (Fl_Callback *)UI_Menu::salesAss_cb, 0, FL_MENU_DIVIDER },
	{ "Robot &Part",          FL_COMMAND + 'p', (Fl_Callback *)UI_Menu::part_cb },
	{ "Robot &Model",          FL_COMMAND + 'm', (Fl_Callback *)UI_Menu::model_cb },
    { 0 },

	{ "&Report", 0, 0, 0, FL_SUBMENU },
	{ "All Orders",         FL_COMMAND + FL_SHIFT + 'x', (Fl_Callback *)UI_Menu::orders_cb },
	{ "Orders by Customer",      FL_COMMAND + FL_SHIFT + 'c', UI_Menu::orderByCust_cb },
	{ "Order by Sales Associate",      FL_COMMAND + FL_SHIFT + 'a', UI_Menu::orderBySA_cb, 0, FL_MENU_DIVIDER },
	{ "All Customers",   FL_COMMAND + FL_CTRL + 'c', UI_Menu::allCust_cb },
	{ "All Sales Associates",   FL_COMMAND + FL_CTRL + 'a', UI_Menu::allSA_cb, 0, FL_MENU_DIVIDER },
	{ "All Robort Models",   FL_COMMAND + FL_SHIFT + 'm', UI_Menu::allModels_cb },
	{ "All Robot Parts",   FL_COMMAND + FL_SHIFT + 'p', UI_Menu::allParts_cb },
	{ 0 },

    { 0 }
};

UI_Menu::UI_Menu(void)
{
}
UI_Menu::UI_Menu(Fl_Window *win)
{
	Fl_Menu_Bar* m = new Fl_Menu_Bar(0, 0, 660, 30);
    m->copy(menuitems, win);
}


UI_Menu::~UI_Menu(void)
{
}
void UI_Menu::new_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::open_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::save_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::saveas_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::quit_cb(Fl_Widget*, void*) 
{
	exit(0);
}
void UI_Menu::order_cb(Fl_Widget*, void*) 
{
	Fl_Window* dlg = new Fl_Window(70, 70 , 400, 300 , "dialog" ) ;
    dlg->end();
	dlg->show();
	dlg->set_modal();
	while (dlg->visible() && Fl::check()) 
		Fl::wait();
}
void UI_Menu::customer_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::salesAss_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::part_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::model_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::orders_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::orderByCust_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::orderBySA_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::allCust_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::allSA_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::allModels_cb(Fl_Widget*, void*) 
{
}
void UI_Menu::allParts_cb(Fl_Widget*, void*) 
{
}
